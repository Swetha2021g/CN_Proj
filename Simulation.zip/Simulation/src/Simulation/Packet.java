package Simulation;

public class Packet {
    double size;
    double emissionTime;

    Packet(double s, double eT)
    {
        size=s;
        emissionTime=eT;
    }
}
